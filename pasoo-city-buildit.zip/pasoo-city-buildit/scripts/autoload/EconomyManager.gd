extends Node

## EconomyManager - Handles all currencies and economic flow
## Inspired by SimCity BuildIt economy system

signal simoleons_changed(new_amount: int)
signal keys_changed(new_amount: int)
signal transaction_completed(type: String, amount: int)

# Currencies
var simoleons: int = 5000          # Main currency (§)
var golden_keys: int = 5           # Premium progression currency
var sim_cash: int = 0              # Optional premium currency

# Economy rates
var tax_income_per_minute: int = 0
var last_tax_time: float = 0.0

func _ready() -> void:
	print("[EconomyManager] Economy system online")
	last_tax_time = Time.get_unix_time_from_system()

func _process(_delta: float) -> void:
	# Simple passive income every 60 seconds
	var now = Time.get_unix_time_from_system()
	if now - last_tax_time >= 60.0:
		last_tax_time = now
		if tax_income_per_minute > 0:
			add_simoleons(tax_income_per_minute)

# --- Simoleons ---
func add_simoleons(amount: int) -> void:
	if amount <= 0:
		return
	simoleons += amount
	simoleons_changed.emit(simoleons)
	transaction_completed.emit("simoleons_gain", amount)

func spend_simoleons(amount: int) -> bool:
	if simoleons >= amount:
		simoleons -= amount
		simoleons_changed.emit(simoleons)
		transaction_completed.emit("simoleons_spend", amount)
		return true
	return false

func can_afford(amount: int) -> bool:
	return simoleons >= amount

# --- Golden Keys ---
func add_keys(amount: int) -> void:
	golden_keys += amount
	keys_changed.emit(golden_keys)

func spend_keys(amount: int) -> bool:
	if golden_keys >= amount:
		golden_keys -= amount
		keys_changed.emit(golden_keys)
		return true
	return false

# --- Helpers ---
func set_tax_income(amount: int) -> void:
	tax_income_per_minute = max(0, amount)

func get_formatted_simoleons() -> String:
	if simoleons >= 1000000:
		return "%.1fM" % (simoleons / 1000000.0)
	elif simoleons >= 1000:
		return "%.1fK" % (simoleons / 1000.0)
	return str(simoleons)