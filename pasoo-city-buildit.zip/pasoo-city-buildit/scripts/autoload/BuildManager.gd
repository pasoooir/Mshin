extends Node

signal building_placed(building_data: Dictionary)
signal building_removed(building_id: String)
signal construction_started(building_id: String)
signal construction_finished(building_id: String)
signal placement_mode_changed(active: bool)

const GRID_SIZE := 2.0
const BuildingScene = preload("res://scenes/buildings/Building.tscn")

var buildings: Dictionary = {}
var selected_building_type: String = ""
var is_placing: bool = false
var factory_count: int = 0

# Building defs inspired by SimCity BuildIt early game
var building_types := {
	# Residential
	"residential_1": {"name": "Small House", "category": "residential", "cost": 0, "size": Vector2i(2, 2), "population": 12, "build_time": 5.0, "color": Color(0.95, 0.72, 0.5), "level": 1},
	"residential_2": {"name": "Apartment", "category": "residential", "cost": 0, "size": Vector2i(2, 2), "population": 28, "build_time": 10.0, "color": Color(0.88, 0.62, 0.68), "level": 3},
	# Commercial
	"building_supplies": {"name": "Building Supplies", "category": "commercial", "cost": 100, "size": Vector2i(2, 2), "population": 0, "build_time": 8.0, "color": Color(0.35, 0.68, 0.95), "level": 1},
	"hardware_store": {"name": "Hardware Store", "category": "commercial", "cost": 500, "size": Vector2i(2, 2), "population": 0, "build_time": 10.0, "color": Color(0.3, 0.55, 0.85), "level": 4},
	"farmers_market": {"name": "Farmer's Market", "category": "commercial", "cost": 800, "size": Vector2i(2, 2), "population": 0, "build_time": 12.0, "color": Color(0.4, 0.75, 0.4), "level": 8},
	"furniture_store": {"name": "Furniture Store", "category": "commercial", "cost": 1200, "size": Vector2i(2, 2), "population": 0, "build_time": 12.0, "color": Color(0.6, 0.45, 0.3), "level": 10},
	# Industrial
	"industrial_1": {"name": "Small Factory", "category": "industrial", "cost": 0, "size": Vector2i(2, 2), "population": 0, "build_time": 8.0, "color": Color(0.55, 0.55, 0.6), "produces": "metal", "level": 1},
	"industrial_2": {"name": "Factory", "category": "industrial", "cost": 500, "size": Vector2i(2, 2), "population": 0, "build_time": 12.0, "color": Color(0.45, 0.45, 0.5), "produces": "wood", "level": 2},
	"industrial_3": {"name": "Factory+", "category": "industrial", "cost": 1500, "size": Vector2i(2, 2), "population": 0, "build_time": 14.0, "color": Color(0.4, 0.42, 0.48), "produces": "plastic", "level": 5},
	# Services
	"power_wind": {"name": "Wind Power", "category": "service", "cost": 1500, "size": Vector2i(1, 1), "population": 0, "build_time": 8.0, "color": Color(0.7, 0.9, 0.85), "power": 8, "level": 1},
	"water_tower": {"name": "Water Tower", "category": "service", "cost": 1500, "size": Vector2i(1, 1), "population": 0, "build_time": 8.0, "color": Color(0.45, 0.72, 0.95), "water": 10, "level": 1},
	"fire_station": {"name": "Fire Station", "category": "service", "cost": 2500, "size": Vector2i(2, 2), "population": 0, "build_time": 10.0, "color": Color(0.92, 0.32, 0.28), "level": 5},
	"police_station": {"name": "Police Station", "category": "service", "cost": 3000, "size": Vector2i(2, 2), "population": 0, "build_time": 10.0, "color": Color(0.28, 0.42, 0.78), "level": 12},
	"sewage_pipe": {"name": "Sewage Pipe", "category": "service", "cost": 2000, "size": Vector2i(1, 1), "population": 0, "build_time": 8.0, "color": Color(0.5, 0.55, 0.4), "level": 8},
	# Parks
	"park_small": {"name": "Small Park", "category": "park", "cost": 300, "size": Vector2i(1, 1), "population": 0, "build_time": 4.0, "color": Color(0.35, 0.75, 0.4), "level": 3, "happiness": 5},
}

func _ready() -> void:
	print("[BuildManager] ", building_types.size(), " building types (SCBI-style unlocks)")

func get_available_buildings(category: String = "") -> Array:
	var result = []
	for key in building_types:
		var def = building_types[key]
		if def.get("level", 1) > GameManager.level:
			continue
		if category != "" and def.category != category:
			continue
		# Factory limit
		if def.category == "industrial" and factory_count >= LevelProgression.max_factories:
			continue
		result.append(key)
	return result

func select_building(type_id: String) -> void:
	if not building_types.has(type_id):
		return
	var def = building_types[type_id]
	if def.get("level", 1) > GameManager.level:
		print("[BuildManager] Locked until level ", def.level)
		return
	if def.category == "industrial" and factory_count >= LevelProgression.max_factories:
		print("[BuildManager] Factory limit reached (", LevelProgression.max_factories, ")")
		return
	selected_building_type = type_id
	is_placing = true
	var road_sys = get_tree().current_scene.get_node_or_null("World/RoadSystem")
	if road_sys: road_sys.set_road_mode(false)
	placement_mode_changed.emit(true)
	print("[BuildManager] Selected: ", def.name, " (Lv", def.get("level",1), ")")

func cancel_placement() -> void:
	selected_building_type = ""
	is_placing = false
	placement_mode_changed.emit(false)
	var ghost = get_tree().current_scene.get_node_or_null("GhostPreview")
	if ghost: ghost.hide_ghost()

func is_cell_free(grid_pos: Vector2i) -> bool:
	for b in buildings.values():
		if is_instance_valid(b) and b.grid_pos == grid_pos:
			return false
	return true

func place_building_at_world(world_pos: Vector3) -> bool:
	if not is_placing or selected_building_type == "": return false
	return place_building(world_to_grid(world_pos))

func place_building(grid_pos: Vector2i) -> bool:
	if not is_placing or selected_building_type == "": return false
	var def = building_types[selected_building_type]
	if def.get("level", 1) > GameManager.level: return false
	if def.cost > 0 and not EconomyManager.can_afford(def.cost):
		print("[BuildManager] Need ", def.cost, " §")
		return false
	if not is_cell_free(grid_pos): return false
	if def.category == "industrial" and factory_count >= LevelProgression.max_factories:
		return false
	
	if def.cost > 0:
		EconomyManager.spend_simoleons(def.cost)
	
	var building_id = "b_%d" % Time.get_ticks_msec()
	var data = {"id": building_id, "type": selected_building_type, "grid_pos": grid_pos, "definition": def, "status": "constructing", "build_time": def.build_time}
	
	var building_node = BuildingScene.instantiate()
	var world = get_tree().current_scene.get_node_or_null("World/Buildings")
	if world == null: world = get_tree().current_scene
	world.add_child(building_node)
	building_node.global_position = grid_to_world(grid_pos)
	building_node.setup(data)
	buildings[building_id] = building_node
	
	if def.category == "industrial":
		factory_count += 1
	
	construction_started.emit(building_id)
	building_placed.emit(data)
	GameManager.add_experience(3)
	print("[BuildManager] Placed ", def.name)
	return true

func world_to_grid(world_pos: Vector3) -> Vector2i:
	return Vector2i(floor(world_pos.x / GRID_SIZE), floor(world_pos.z / GRID_SIZE))

func grid_to_world(grid_pos: Vector2i) -> Vector3:
	return Vector3(grid_pos.x * GRID_SIZE + GRID_SIZE * 0.5, 0.0, grid_pos.y * GRID_SIZE + GRID_SIZE * 0.5)

func get_selected_size() -> Vector2i:
	if selected_building_type != "" and building_types.has(selected_building_type):
		return building_types[selected_building_type].size
	return Vector2i(2, 2)
