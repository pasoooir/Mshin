extends Node

## ProductionManager - Accurate materials from SimCity BuildIt wiki
## Industrial raw + Commercial crafted items

signal item_produced(item_id: String, amount: int)

# Industrial Raw Materials (from wiki Building Materials page)
# time in seconds (scaled down from real minutes for prototype feel)
var raw_materials := {
	"metal":    {"name": "Metal",     "time": 12.0,  "value": 10,  "level": 1},
	"wood":     {"name": "Wood",      "time": 25.0,  "value": 20,  "level": 2},
	"plastic":  {"name": "Plastic",   "time": 55.0,  "value": 25,  "level": 5},
	"seeds":    {"name": "Seeds",     "time": 80.0,  "value": 30,  "level": 7},
	"minerals": {"name": "Minerals",   "time": 110.0, "value": 40,  "level": 11},
	"chemicals":{"name": "Chemicals", "time": 160.0, "value": 60,  "level": 13},
	"textiles": {"name": "Textiles",  "time": 200.0, "value": 90,  "level": 15},
	"sugar":    {"name": "Sugar & Spices", "time": 240.0, "value": 110, "level": 17},
	"glass":    {"name": "Glass",     "time": 280.0, "value": 120, "level": 19},
	"feed":     {"name": "Animal Feed","time": 320.0, "value": 140, "level": 23},
	"electrical":{"name": "Electrical Components", "time": 360.0, "value": 160, "level": 29},
}

# Commercial crafted items (Building Supplies, Hardware, etc.)
var crafted_items := {
	"nails":     {"name": "Nails",      "time": 18.0, "value": 40,  "requires": {"metal": 1}, "level": 1, "store": "building_supplies"},
	"planks":    {"name": "Planks",     "time": 30.0, "value": 50,  "requires": {"wood": 1}, "level": 3, "store": "building_supplies"},
	"bricks":    {"name": "Bricks",     "time": 45.0, "value": 60,  "requires": {"minerals": 1}, "level": 13, "store": "building_supplies"},
	"cement":    {"name": "Cement",     "time": 60.0, "value": 80,  "requires": {"minerals": 2}, "level": 14, "store": "building_supplies"},
	"glue":      {"name": "Glue",       "time": 40.0, "value": 55,  "requires": {"plastic": 1}, "level": 15, "store": "building_supplies"},
	"paint":     {"name": "Paint",      "time": 50.0, "value": 70,  "requires": {"plastic": 1, "chemicals": 1}, "level": 16, "store": "hardware_store"},
	"hammer":    {"name": "Hammer",     "time": 35.0, "value": 55,  "requires": {"metal": 1, "wood": 1}, "level": 4, "store": "hardware_store"},
	"measuring_tape": {"name": "Measuring Tape", "time": 40.0, "value": 60, "requires": {"metal": 1, "plastic": 1}, "level": 6, "store": "hardware_store"},
	"shovel":    {"name": "Shovel",     "time": 45.0, "value": 65,  "requires": {"metal": 1, "wood": 1, "plastic": 1}, "level": 9, "store": "hardware_store"},
	"chair":     {"name": "Chair",      "time": 40.0, "value": 65,  "requires": {"wood": 1, "planks": 1}, "level": 10, "store": "furniture_store"},
	"table":     {"name": "Table",      "time": 55.0, "value": 90,  "requires": {"planks": 2}, "level": 16, "store": "furniture_store"},
	"vegetables":{"name": "Vegetables", "time": 50.0, "value": 45,  "requires": {"seeds": 1}, "level": 8, "store": "farmers_market"},
}

# Residential upgrade requirements per stage (1→2, 2→3, ... 5→6)
# Inspired by early-game SCBI patterns: early stages need simple materials
var upgrade_requirements := {
	1: [{"item": "nails", "amount": 1}, {"item": "metal", "amount": 1}],           # → stage 2
	2: [{"item": "planks", "amount": 1}, {"item": "wood", "amount": 1}],            # → stage 3
	3: [{"item": "hammer", "amount": 1}, {"item": "nails", "amount": 2}],           # → stage 4
	4: [{"item": "bricks", "amount": 1}, {"item": "cement", "amount": 1}],          # → stage 5
	5: [{"item": "paint", "amount": 1}, {"item": "planks", "amount": 2}, {"item": "glass", "amount": 1}],  # → stage 6
}

# Population per residential upgrade stage (standard zone, scaled from wiki ~52/104/154/313/752/1836)
var residential_population := {
	1: 15,
	2: 30,
	3: 50,
	4: 90,
	5: 160,
	6: 280,
}

func _ready() -> void:
	print("[ProductionManager] ", raw_materials.size(), " raw, ", crafted_items.size(), " crafted")

func get_available_raw() -> Array:
	var result = []
	for id in raw_materials:
		if raw_materials[id].level <= GameManager.level:
			result.append(id)
	return result

func get_available_crafted() -> Array:
	var result = []
	for id in crafted_items:
		if crafted_items[id].level <= GameManager.level:
			result.append(id)
	return result

func can_craft(item_id: String) -> bool:
	if not crafted_items.has(item_id):
		return false
	if crafted_items[item_id].level > GameManager.level:
		return false
	var reqs = crafted_items[item_id].get("requires", {})
	for mat in reqs:
		if StorageManager.get_item_count(mat) < reqs[mat]:
			return false
	return true

func craft_item(item_id: String) -> bool:
	if not can_craft(item_id):
		return false
	var reqs = crafted_items[item_id].requires
	for mat in reqs:
		StorageManager.remove_item(mat, reqs[mat])
	if StorageManager.add_item(item_id, 1):
		item_produced.emit(item_id, 1)
		GameManager.add_experience(5)
		return true
	return false

func get_item_value(item_id: String) -> int:
	if raw_materials.has(item_id):
		return raw_materials[item_id].value
	if crafted_items.has(item_id):
		return crafted_items[item_id].value
	return 5

func get_production_time(item_id: String) -> float:
	if raw_materials.has(item_id):
		return raw_materials[item_id].time
	if crafted_items.has(item_id):
		return crafted_items[item_id].time
	return 20.0

func get_upgrade_requirements(from_stage: int) -> Array:
	return upgrade_requirements.get(from_stage, [])

func get_population_for_stage(stage: int) -> int:
	return residential_population.get(clamp(stage, 1, 6), 15)

func can_afford_upgrade(from_stage: int) -> bool:
	var reqs = get_upgrade_requirements(from_stage)
	if reqs.is_empty():
		return false
	for r in reqs:
		if StorageManager.get_item_count(r.item) < r.amount:
			return false
	return true

func consume_upgrade_materials(from_stage: int) -> bool:
	if not can_afford_upgrade(from_stage):
		return false
	for r in get_upgrade_requirements(from_stage):
		StorageManager.remove_item(r.item, r.amount)
	return true
