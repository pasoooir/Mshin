extends Node

## LevelProgression - Based on SimCity BuildIt Level Up Table
## Unlocks materials, factories, services and buildings by level

signal unlocked(what: String, level: int)
signal factory_slot_unlocked(count: int)

# XP required to reach each level (approximate from community data)
var xp_table := {
	1: 0, 2: 50, 3: 120, 4: 230, 5: 380,
	6: 560, 7: 790, 8: 1060, 9: 1380, 10: 1760,
	11: 2200, 12: 2680, 13: 3240, 14: 3900, 15: 4610,
	16: 5430, 17: 6320, 18: 7300, 19: 8320, 20: 9400
}

# What unlocks at each level (simplified early game from real table)
var unlocks := {
	1: {
		"materials": ["metal", "nails"],
		"commercial": ["building_supplies"],
		"factories": 2,
		"services": ["power", "water"],
		"other": ["roads", "residential"]
	},
	2: {
		"materials": ["wood"],
		"factories": 3
	},
	3: {
		"materials": ["planks"],
		"factories": 4,
		"other": ["parks"]
	},
	4: {
		"materials": ["hammer"],
		"commercial": ["hardware_store"],
		"factories": 4,
		"other": ["storage_upgrade"]
	},
	5: {
		"materials": ["plastic"],
		"services": ["fire"],
		"buildings": ["city_hall", "fire_station"]
	},
	6: {
		"materials": ["measuring_tape"],
		"factories": 5,
		"buildings": ["mayors_mansion"]
	},
	7: {
		"materials": ["seeds"]
	},
	8: {
		"materials": ["vegetables"],
		"commercial": ["farmers_market"],
		"services": ["sewage"]
	},
	9: {
		"materials": ["shovel"],
		"other": ["4lane_road"]
	},
	10: {
		"materials": ["chair"],
		"commercial": ["furniture_store"],
		"other": ["education", "transportation"]
	},
	12: {
		"factories": 6,
		"services": ["police"]
	},
	13: {
		"materials": ["chemicals", "bricks"]
	},
	14: {
		"materials": ["grass", "cement"],
		"commercial": ["gardening_supplies"],
		"services": ["waste"]
	},
	15: {
		"materials": ["glue", "textiles"],
		"other": ["6lane_road", "beach"]
	},
	16: {
		"materials": ["paint", "table"],
		"services": ["health"]
	},
	18: {
		"materials": ["donut", "fruit"],
		"commercial": ["donut_shop"],
		"factories": 7
	},
	20: {
		"other": ["entertainment", "avenue"]
	}
}

# Population-based unlocks (from wiki)
var population_unlocks := {
	4000: "basic_factory_upgrade",
	8000: "trade_depot",
	10000: "global_trade_hq",
	12000: "monster_trouble",
	20000: "cargo_ship",
	27000: "mass_production_factory"
}

var unlocked_materials: Array = ["metal", "nails"]
var unlocked_commercial: Array = ["building_supplies"]
var unlocked_services: Array = ["power", "water"]
var max_factories: int = 2
var unlocked_features: Array = ["roads", "residential"]

func _ready() -> void:
	print("[LevelProgression] Loaded - early game mirrors SimCity BuildIt")
	_apply_level(GameManager.level)

func _apply_level(level: int) -> void:
	for lv in range(1, level + 1):
		if not unlocks.has(lv):
			continue
		var data = unlocks[lv]
		if data.has("materials"):
			for m in data.materials:
				if m not in unlocked_materials:
					unlocked_materials.append(m)
					unlocked.emit("material:" + m, lv)
		if data.has("commercial"):
			for c in data.commercial:
				if c not in unlocked_commercial:
					unlocked_commercial.append(c)
					unlocked.emit("commercial:" + c, lv)
		if data.has("services"):
			for s in data.services:
				if s not in unlocked_services:
					unlocked_services.append(s)
					unlocked.emit("service:" + s, lv)
		if data.has("factories"):
			if data.factories > max_factories:
				max_factories = data.factories
				factory_slot_unlocked.emit(max_factories)
		if data.has("other"):
			for o in data.other:
				if o not in unlocked_features:
					unlocked_features.append(o)
					unlocked.emit("feature:" + o, lv)
		if data.has("buildings"):
			for b in data.buildings:
				if b not in unlocked_features:
					unlocked_features.append(b)
					unlocked.emit("building:" + b, lv)

func on_level_up(new_level: int) -> void:
	_apply_level(new_level)
	print("[LevelProgression] Level ", new_level, " applied. Factories: ", max_factories)

func is_material_unlocked(id: String) -> bool:
	return id in unlocked_materials

func is_service_unlocked(id: String) -> bool:
	return id in unlocked_services

func is_feature_unlocked(id: String) -> bool:
	return id in unlocked_features

func get_xp_for_level(level: int) -> int:
	return xp_table.get(level, level * 500)

func check_population_unlocks(pop: int) -> void:
	for threshold in population_unlocks:
		if pop >= threshold:
			var feat = population_unlocks[threshold]
			if feat not in unlocked_features:
				unlocked_features.append(feat)
				unlocked.emit("population:" + feat, threshold)
				print("[LevelProgression] Population unlock: ", feat)
