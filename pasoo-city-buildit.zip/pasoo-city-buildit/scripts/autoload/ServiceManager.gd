extends Node

## ServiceManager - Power, Water, coverage like SimCity BuildIt

signal power_changed(total: int, used: int)
signal water_changed(total: int, used: int)

var total_power: int = 0
var used_power: int = 0
var total_water: int = 0
var used_water: int = 0

func _ready() -> void:
	print("[ServiceManager] Services online")

func register_power(amount: int) -> void:
	total_power += amount
	power_changed.emit(total_power, used_power)

func register_water(amount: int) -> void:
	total_water += amount
	water_changed.emit(total_water, used_water)

func consume_power(amount: int) -> bool:
	if used_power + amount <= total_power:
		used_power += amount
		power_changed.emit(total_power, used_power)
		return true
	return false

func has_enough_power() -> bool:
	return total_power >= used_power

func has_enough_water() -> bool:
	return total_water >= used_water

func get_power_status() -> String:
	return "%d/%d" % [used_power, total_power]

func get_water_status() -> String:
	return "%d/%d" % [used_water, total_water]

func recalculate_from_buildings() -> void:
	total_power = 0
	total_water = 0
	used_power = 0
	used_water = 0
	
	for b in BuildManager.buildings.values():
		if not is_instance_valid(b):
			continue
		if b.status != "completed":
			continue
		var def = b.definition
		if def.has("power"):
			total_power += def.power
		if def.has("water"):
			total_water += def.water
		# Each residential consumes some
		if def.get("category") == "residential":
			used_power += 2
			used_water += 2
	
	power_changed.emit(total_power, used_power)
	water_changed.emit(total_water, used_water)