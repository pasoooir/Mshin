extends Node3D

## CameraController - Mobile-friendly camera with pan + pinch zoom
## Designed to feel like SimCity BuildIt

@export var move_speed: float = 15.0
@export var zoom_speed: float = 0.15
@export var min_zoom: float = 8.0
@export var max_zoom: float = 45.0
@export var rotation_x: float = -45.0  # Degrees looking down
@export var rotation_y: float = 45.0   # Isometric-ish angle

@onready var camera: Camera3D = $Camera3D

var is_panning: bool = false
var last_pan_position: Vector2 = Vector2.ZERO
var current_zoom: float = 25.0

# Touch tracking for pinch
var touch_points: Dictionary = {}
var last_pinch_distance: float = 0.0

func _ready() -> void:
	# Set initial isometric-style rotation
	rotation_degrees = Vector3(rotation_x, rotation_y, 0)
	_update_camera_zoom()
	print("[CameraController] Ready - Pinch to zoom, drag to pan")

func _unhandled_input(event: InputEvent) -> void:
	# --- Mouse (Desktop testing) ---
	if event is InputEventMouseButton:
		if event.button_index == MOUSE_BUTTON_LEFT:
			is_panning = event.pressed
			last_pan_position = event.position
		elif event.button_index == MOUSE_BUTTON_WHEEL_UP:
			_zoom(-zoom_speed * 3.0)
		elif event.button_index == MOUSE_BUTTON_WHEEL_DOWN:
			_zoom(zoom_speed * 3.0)
	
	elif event is InputEventMouseMotion and is_panning:
		var delta = event.position - last_pan_position
		_pan(delta)
		last_pan_position = event.position
	
	# --- Touch (Mobile) ---
	elif event is InputEventScreenTouch:
		if event.pressed:
			touch_points[event.index] = event.position
		else:
			touch_points.erase(event.index)
			if touch_points.size() < 2:
				last_pinch_distance = 0.0
	
	elif event is InputEventScreenDrag:
		touch_points[event.index] = event.position
		
		if touch_points.size() == 1:
			# Single finger → Pan
			var delta = event.relative
			_pan(delta)
		
		elif touch_points.size() == 2:
			# Two fingers → Pinch Zoom
			var positions = touch_points.values()
			var dist = positions[0].distance_to(positions[1])
			
			if last_pinch_distance > 0.0:
				var diff = last_pinch_distance - dist
				_zoom(diff * zoom_speed * 0.05)
			
			last_pinch_distance = dist

func _pan(screen_delta: Vector2) -> void:
	# Convert screen movement to world movement based on camera orientation
	var right = global_transform.basis.x
	var forward = global_transform.basis.z
	forward.y = 0
	forward = forward.normalized()
	
	var move = (-right * screen_delta.x + -forward * screen_delta.y) * (current_zoom * 0.002)
	global_position += move

func _zoom(amount: float) -> void:
	current_zoom = clamp(current_zoom + amount, min_zoom, max_zoom)
	_update_camera_zoom()

func _update_camera_zoom() -> void:
	if camera:
		# Move camera along its local Z axis for zoom effect
		camera.position.z = current_zoom