extends Node3D

## RoadSystem - Simple road placement and visual
## Roads are required for buildings to function (SimCity style)

signal road_placed(grid_pos: Vector2i)
signal road_removed(grid_pos: Vector2i)

const GRID_SIZE := 2.0

var roads: Dictionary = {}  # Vector2i -> MeshInstance3D
var is_road_mode: bool = false

func _ready() -> void:
	print("[RoadSystem] Ready")

func set_road_mode(active: bool) -> void:
	is_road_mode = active
	if active:
		BuildManager.cancel_placement()

func has_road(grid_pos: Vector2i) -> bool:
	return roads.has(grid_pos)

func place_road(grid_pos: Vector2i) -> bool:
	if roads.has(grid_pos):
		return false
	
	# Cost
	if not EconomyManager.can_afford(50):
		return false
	EconomyManager.spend_simoleons(50)
	
	var mesh = _create_road_mesh()
	add_child(mesh)
	mesh.global_position = Vector3(
		grid_pos.x * GRID_SIZE + GRID_SIZE * 0.5,
		0.02,
		grid_pos.y * GRID_SIZE + GRID_SIZE * 0.5
	)
	
	roads[grid_pos] = mesh
	road_placed.emit(grid_pos)
	return true

func remove_road(grid_pos: Vector2i) -> void:
	if not roads.has(grid_pos):
		return
	roads[grid_pos].queue_free()
	roads.erase(grid_pos)
	road_removed.emit(grid_pos)

func place_road_at_world(world_pos: Vector3) -> bool:
	var grid = Vector2i(floor(world_pos.x / GRID_SIZE), floor(world_pos.z / GRID_SIZE))
	return place_road(grid)

func _create_road_mesh() -> MeshInstance3D:
	var mi = MeshInstance3D.new()
	var box = BoxMesh.new()
	box.size = Vector3(GRID_SIZE * 0.95, 0.08, GRID_SIZE * 0.95)
	mi.mesh = box
	
	var mat = StandardMaterial3D.new()
	mat.albedo_color = Color(0.22, 0.22, 0.25)
	mat.roughness = 0.9
	mi.material_override = mat
	
	# Center line
	var line = MeshInstance3D.new()
	var line_box = BoxMesh.new()
	line_box.size = Vector3(0.15, 0.09, GRID_SIZE * 0.6)
	line.mesh = line_box
	var line_mat = StandardMaterial3D.new()
	line_mat.albedo_color = Color(0.9, 0.85, 0.3)
	line.material_override = line_mat
	line.position.y = 0.01
	mi.add_child(line)
	
	return mi

func get_road_count() -> int:
	return roads.size()