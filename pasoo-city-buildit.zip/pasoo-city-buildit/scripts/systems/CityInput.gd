extends Node3D

@onready var camera: Camera3D = null

func _ready() -> void:
	camera = get_viewport().get_camera_3d()

func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventMouseMotion and BuildManager.is_placing:
		_update_ghost(event.position)
	
	if event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
		_handle_click(event.position)
	elif event is InputEventScreenTouch and event.pressed and event.index == 0:
		_handle_click(event.position)

func _handle_click(screen_pos: Vector2) -> void:
	var hit = _raycast_ground(screen_pos)
	if hit == null:
		return
	
	var road_sys = get_tree().current_scene.get_node_or_null("World/RoadSystem")
	if road_sys and road_sys.is_road_mode:
		road_sys.place_road_at_world(hit)
		return
	
	if BuildManager.is_placing:
		BuildManager.place_building_at_world(hit)
		return
	
	_try_interact(hit)

func _update_ghost(screen_pos: Vector2) -> void:
	var hit = _raycast_ground(screen_pos)
	var ghost = get_tree().current_scene.get_node_or_null("GhostPreview")
	if ghost == null or hit == null:
		return
	var grid = BuildManager.world_to_grid(hit)
	var world = BuildManager.grid_to_world(grid)
	var cost = 0
	if BuildManager.selected_building_type != "":
		cost = BuildManager.building_types[BuildManager.selected_building_type].get("cost", 0)
	var valid = BuildManager.is_cell_free(grid) and (cost == 0 or EconomyManager.can_afford(cost))
	ghost.show_at(world, BuildManager.get_selected_size(), valid)

func _raycast_ground(screen_pos: Vector2) -> Variant:
	if camera == null:
		camera = get_viewport().get_camera_3d()
	if camera == null:
		return null
	var from = camera.project_ray_origin(screen_pos)
	var dir = camera.project_ray_normal(screen_pos)
	if abs(dir.y) < 0.0001:
		return null
	var t = -from.y / dir.y
	if t < 0:
		return null
	return from + dir * t

func _try_interact(world_pos: Vector3) -> void:
	var grid = BuildManager.world_to_grid(world_pos)
	for b in BuildManager.buildings.values():
		if not is_instance_valid(b) or b.grid_pos != grid:
			continue
		# Residential upgrade
		if b.definition.get("category") == "residential":
			if b.upgrade_ready:
				b.try_upgrade()
			else:
				print(b.get_info())
			return
		# Factory collect
		if b.has_method("collect_production"):
			b.collect_production()
		return
