extends Node3D

## GhostPreview - Shows green/red transparent building while placing
## Classic city-builder UX like SimCity BuildIt

var ghost_mesh: MeshInstance3D
var is_valid: bool = true
var current_size: Vector2i = Vector2i(2, 2)

func _ready() -> void:
	visible = false
	ghost_mesh = MeshInstance3D.new()
	var box = BoxMesh.new()
	box.size = Vector3(3.4, 2.0, 3.4)
	ghost_mesh.mesh = box
	add_child(ghost_mesh)
	_set_color(true)

func show_at(world_pos: Vector3, size: Vector2i = Vector2i(2, 2), valid: bool = true) -> void:
	current_size = size
	visible = true
	global_position = world_pos
	global_position.y = 0.05
	
	if ghost_mesh.mesh is BoxMesh:
		ghost_mesh.mesh.size = Vector3(size.x * 1.7, 1.8, size.y * 1.7)
	
	_set_color(valid)
	is_valid = valid

func hide_ghost() -> void:
	visible = false

func _set_color(valid: bool) -> void:
	var mat = StandardMaterial3D.new()
	mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	mat.albedo_color = Color(0.2, 0.95, 0.35, 0.45) if valid else Color(0.95, 0.2, 0.2, 0.45)
	mat.roughness = 0.3
	ghost_mesh.material_override = mat