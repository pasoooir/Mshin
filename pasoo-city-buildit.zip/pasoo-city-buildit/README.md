# Pasoo City BuildIt 🏙️

**نسخه: 0.5.0** — ارتقای خانه + متریال دقیق

منبع: [Level Up Table](https://simcity-buildit.fandom.com/wiki/Level_Up_Table) · [Building Materials](https://simcity-buildit.fandom.com/wiki/Building_Materials)

---

## جدید در ۰.۵

### ارتقای خانه (مثل SimCity BuildIt)
- هر خانه مسکونی **۶ مرحله** دارد
- جمعیت تقریبی: ۱۵ → ۳۰ → ۵۰ → ۹۰ → ۱۶۰ → ۲۸۰
- وقتی مواد لازم را داری، **کلاه زرد** روی خانه ظاهر می‌شود
- روی خانه کلیک کن تا ارتقا انجام شود
- با هر ارتقا: جمعیت بیشتر + XP + سکه
- ارتفاع بصری ساختمان با ارتقا بیشتر می‌شود

### مواد مورد نیاز ارتقا
| از مرحله | مواد لازم |
|---------|-----------|
| ۱ → ۲ | Nails + Metal |
| ۲ → ۳ | Planks + Wood |
| ۳ → ۴ | Hammer + Nails×2 |
| ۴ → ۵ | Bricks + Cement |
| ۵ → ۶ | Paint + Planks×2 + Glass |

### متریال دقیق‌تر (از ویکی)
**خام (کارخانه):** Metal, Wood, Plastic, Seeds, Minerals, Chemicals, Textiles, Sugar, Glass, Animal Feed, Electrical Components

**ساخته‌شده:** Nails, Planks, Bricks, Cement, Glue, Paint, Hammer, Measuring Tape, Shovel, Chair, Table, Vegetables

---

## چطور بازی کنی

1. **🏠** خانه بساز (رایگان)
2. **🏭** کارخانه بساز → صبر کن ✅ → کلیک = جمع‌آوری Metal/Wood
3. مواد را جمع کن تا کلاه زرد روی خانه بیاید
4. روی خانه کلیک کن → ارتقا
5. سطح بالا برو → مواد و ساختمان جدید باز می‌شود

---

## نقشه راه بعدی
- [ ] UI نمایش مواد لازم برای ارتقا
- [ ] Trade Depot
- [ ] محدوده پوشش خدمات
- [ ] منوی بازشو دسته‌ها
- [ ] مدل‌های زیباتر

---

Godot 4.3+ → `scenes/main.tscn`  
کنترل: درگ=جابجایی | دو انگشت=زوم | کلیک=ساخت/جمع‌آوری/ارتقای خانه
